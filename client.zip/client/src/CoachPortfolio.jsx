import { useEffect, useMemo, useRef } from "react"
import gsap from "gsap"

export default function CoachPortfolio({ onClose }) {
  const rootRef = useRef(null)
  const particleCanvasRef = useRef(null)

  const skillsRef = useRef([])
  const countersRef = useRef([])

  // sections à animer
  const headerRef = useRef(null)
  const expertiseRef = useRef(null)
  const expRef = useRef(null)
  const eduRef = useRef(null)
  const timelineRef = useRef(null)
  const visionRef = useRef(null)

  const skills = useMemo(
    () => [
      { name: "Big Data & Data Engineering", value: 92 },
      { name: "Intelligence Artificielle", value: 88 },
      { name: "Flutter & Dart (D-CLIC OIF)", value: 90 },
      { name: "Java & Kotlin (Android)", value: 83 },
      { name: "Développement Web (Front & Back)", value: 87 },
      { name: "IoT & Systèmes embarqués", value: 80 },
      { name: "MERISE / UP / UP7", value: 89 },
    ],
    []
  )

  const timelineItems = useMemo(
    () => [
      { year: "2026", title: "Big Data Coaching", desc: "Lancement & montée en puissance du programme premium." },
      { year: "2025", title: "Recherche IA & Big Data", desc: "Publications, architecture data, projets appliqués." },
      { year: "2024", title: "Plateformes Web & Mobile", desc: "Déploiements pro, apps Android, dashboards." },
      { year: "2023", title: "IoT & Systèmes intelligents", desc: "Capteurs, MQTT, solutions terrain." },
    ],
    []
  )

  const setSkillRef = (el, i) => (skillsRef.current[i] = el)
  const setCounterRef = (el, i) => (countersRef.current[i] = el)

  /* =========================
     GSAP: sections + skills + timeline
  ========================= */
  useEffect(() => {
    const ctx = gsap.context(() => {
      // 1) Intro header
      if (headerRef.current) {
        gsap.fromTo(
          headerRef.current.children,
          { y: 18, opacity: 0 },
          { y: 0, opacity: 1, duration: 0.8, stagger: 0.08, ease: "power3.out" }
        )
      }

      // 2) Sections (card par card)
      const sections = [
        expertiseRef.current,
        expRef.current,
        eduRef.current,
        timelineRef.current,
        visionRef.current,
      ].filter(Boolean)

      sections.forEach((sec, idx) => {
        gsap.fromTo(
          sec,
          { y: 22, opacity: 0 },
          { y: 0, opacity: 1, duration: 0.75, delay: 0.08 * idx, ease: "power3.out" }
        )
      })

      // 3) Skills animate
      skillsRef.current.forEach((bar, index) => {
        if (!bar) return
        const value = parseInt(bar.getAttribute("data-progress"), 10)
        const counter = countersRef.current[index]

        gsap.to(bar, { width: value + "%", duration: 1.4, ease: "power3.out", delay: 0.25 })

        gsap.fromTo(
          counter,
          { innerText: 0 },
          {
            innerText: value,
            duration: 1.4,
            ease: "power3.out",
            snap: { innerText: 1 },
            delay: 0.25,
            onUpdate: function () {
              counter.innerText = Math.ceil(counter.innerText) + "%"
            },
          }
        )
      })

      // 4) Timeline line draw + items reveal
      const line = rootRef.current?.querySelector(".tlLine")
      const items = rootRef.current?.querySelectorAll(".tlItem")

      if (line) {
        gsap.fromTo(line, { scaleY: 0 }, { scaleY: 1, transformOrigin: "top", duration: 1.0, ease: "power2.out", delay: 0.25 })
      }
      if (items?.length) {
        gsap.fromTo(
          items,
          { y: 18, opacity: 0 },
          { y: 0, opacity: 1, duration: 0.7, stagger: 0.12, ease: "power3.out", delay: 0.45 }
        )
      }
    }, rootRef)

    return () => ctx.revert()
  }, [])

  /* =========================
     Particles canvas (léger + performant)
  ========================= */
  useEffect(() => {
    const canvas = particleCanvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext("2d", { alpha: true })
    let raf = 0

    const DPR = Math.min(window.devicePixelRatio || 1, 2)
    const state = { w: 0, h: 0, particles: [] }

    const resize = () => {
      const parent = canvas.parentElement
      if (!parent) return
      state.w = parent.clientWidth
      state.h = parent.clientHeight
      canvas.width = Math.floor(state.w * DPR)
      canvas.height = Math.floor(state.h * DPR)
      canvas.style.width = state.w + "px"
      canvas.style.height = state.h + "px"
      ctx.setTransform(DPR, 0, 0, DPR, 0, 0)

      // init particles
      const count = Math.floor(Math.min(70, (state.w * state.h) / 16000)) // adaptatif
      state.particles = Array.from({ length: count }).map(() => ({
        x: Math.random() * state.w,
        y: Math.random() * state.h,
        r: 1 + Math.random() * 2.2,
        vx: (Math.random() - 0.5) * 0.35,
        vy: (Math.random() - 0.5) * 0.35,
        a: 0.15 + Math.random() * 0.25,
      }))
    }

    const tick = () => {
      ctx.clearRect(0, 0, state.w, state.h)

      // draw
      for (const p of state.particles) {
        p.x += p.vx
        p.y += p.vy

        if (p.x < -20) p.x = state.w + 20
        if (p.x > state.w + 20) p.x = -20
        if (p.y < -20) p.y = state.h + 20
        if (p.y > state.h + 20) p.y = -20

        ctx.beginPath()
        ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2)
        ctx.fillStyle = `rgba(255,255,255,${p.a})`
        ctx.fill()
      }

      // lines
      for (let i = 0; i < state.particles.length; i++) {
        for (let j = i + 1; j < state.particles.length; j++) {
          const a = state.particles[i]
          const b = state.particles[j]
          const dx = a.x - b.x
          const dy = a.y - b.y
          const d2 = dx * dx + dy * dy
          const max = 120 * 120
          if (d2 < max) {
            const alpha = 0.12 * (1 - d2 / max)
            ctx.strokeStyle = `rgba(0,198,255,${alpha})`
            ctx.lineWidth = 1
            ctx.beginPath()
            ctx.moveTo(a.x, a.y)
            ctx.lineTo(b.x, b.y)
            ctx.stroke()
          }
        }
      }

      raf = requestAnimationFrame(tick)
    }

    resize()
    window.addEventListener("resize", resize, { passive: true })
    raf = requestAnimationFrame(tick)

    return () => {
      cancelAnimationFrame(raf)
      window.removeEventListener("resize", resize)
    }
  }, [])

  return (
    <div className="modalOverlay" onClick={onClose}>
      <div
        ref={rootRef}
        className="modalContent coachPortfolioPremium scrollableModal"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Background particles */}
        <div className="particlesBg" aria-hidden="true">
          <canvas ref={particleCanvasRef} />
          <div className="particlesGlow" />
        </div>

        <button className="modalClose" onClick={onClose} type="button">
          ✕
        </button>

        {/* ================= HEADER ================= */}
        <div className="coachHeader centeredHeader" ref={headerRef}>
          <img src="/img/georges.jpeg" alt="Dr Maloani" className="coachImgCircle" />
          <h2>Dr MALOANI SAIDI Georges</h2>
          <h4>Big Data Architect | AI Researcher | IoT & Mobile Specialist</h4>
          <p className="coachTagline">PhD Candidate in Computer Science – Artificial Intelligence & Big Data</p>
        </div>

        {/* ================= EXPERTISE ================= */}
        <div className="portfolioSection" ref={expertiseRef}>
          <h3>📊 Niveau d’Expertise</h3>

          {skills.map((skill, index) => (
            <div className="skillItem" key={skill.name}>
              <div className="skillHeader">
                <span>{skill.name}</span>
                <span ref={(el) => setCounterRef(el, index)} className="skillCounter">
                  0%
                </span>
              </div>

              <div className="skillBar">
                <div
                  ref={(el) => setSkillRef(el, index)}
                  data-progress={skill.value}
                  className="skillProgress"
                />
              </div>
            </div>
          ))}
        </div>

        <div className="portfolioSection" ref={expRef}>
          <h3>🚀 Expérience Professionnelle</h3>
          <ul className="portfolioList">
            <li>Assistant publication doctorale – University of Lisala</li>
            <li>IT Officer – Swiss Cooperation Project</li>
            <li>Développement plateformes Web & Mobile</li>
          </ul>
        </div>

        <div className="portfolioSection" ref={eduRef}>
          <h3>🎓 Formation Académique</h3>
          <ul className="portfolioList">
            <li>PhD Candidate – Computer Science (AI & Big Data)</li>
            <li>Master MIS – Distinction</li>
            <li>Bachelor ICT – Excellent</li>
          </ul>
        </div>

        {/* ================= TIMELINE ================= */}
        <div className="portfolioSection" ref={timelineRef}>
          <h3>🧭 Parcours (Timeline)</h3>

          <div className="timelineWrap">
            <div className="tlLine" />
            <div className="tlItems">
              {timelineItems.map((t) => (
                <div className="tlItem" key={t.year}>
                  <div className="tlDot" />
                  <div className="tlCard">
                    <div className="tlTop">
                      <span className="tlYear">{t.year}</span>
                      <span className="tlTitle">{t.title}</span>
                    </div>
                    <p className="tlDesc">{t.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="portfolioSection visionSection" ref={visionRef}>
          <h3>🌍 Vision</h3>
          <p>Transformer l’Afrique par le Big Data, l’IA et les systèmes intelligents.</p>
        </div>
      </div>
    </div>
  )
}