import "./App.css"

export default function CoachProfile() {
  return (
    <div className="page coachPage">

      <div className="container coachFull">

        <img 
          src="/img/georges.jpeg" 
          alt="Coach" 
          className="coachImgLarge"
        />

        <div className="coachInfoFull">
          <h1>Dr MALOANI SAIDI Georges</h1>
          <h3>Big Data Architect | AI Researcher | CEO MS Solutions Lab</h3>

          <p>
            Doctorant en Informatique spécialisé en Big Data,
            systèmes distribués et intelligence artificielle.
          </p>

          <p>
            Fondateur de MS Solutions Lab, il accompagne les
            ingénieurs africains vers un positionnement
            international stratégique.
          </p>

          <p>
            Domaines d'expertise :
            Big Data Architecture • Spark • Cloud • IoT • IA • Research Publishing
          </p>

        </div>

      </div>

    </div>
  )
}