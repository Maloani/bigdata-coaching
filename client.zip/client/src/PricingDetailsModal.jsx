import { useEffect } from "react"

export default function PricingDetailsModal({
  selectedPlan,
  setSelectedPlan,
  setShowRegister
}) {

  useEffect(() => {
    const handleKey = (e) => {
      if (e.key === "Escape") setSelectedPlan(null)
    }
    window.addEventListener("keydown", handleKey)
    return () => window.removeEventListener("keydown", handleKey)
  }, [setSelectedPlan])

  if (!selectedPlan) return null

  const plans = {
    starter: {
      title: "Starter – 99$",
      duration: "Accès 6 mois",
      description:
        "Formation idéale pour débuter en Big Data & Data Analytics avec des bases solides.",
      features: [
        "SQL avancé & optimisation",
        "Python Data Analysis (Pandas, Numpy)",
        "Introduction Apache Spark",
        "Mini projet guidé",
        "Support communauté privée",
        "Accès aux mises à jour",
      ],
    },

    pro: {
      title: "Pro – 249$",
      duration: "Accès 12 mois",
      description:
        "Programme complet pour devenir Data Engineer et construire un portfolio professionnel.",
      features: [
        "Tout Starter inclus",
        "Pipeline Big Data complet",
        "Architecture Data Lake & ETL",
        "Projet réel portfolio",
        "Préparation entretien technique",
        "Mentorat groupe live hebdomadaire",
        "Accès ressources premium",
      ],
    },

    elite: {
      title: "Elite – 599$",
      duration: "Accès illimité",
      description:
        "Programme élite pour devenir architecte Big Data & IA avec accompagnement personnalisé.",
      features: [
        "Tout Pro inclus",
        "Architecture distribuée avancée",
        "Projet IA production-ready",
        "Mentorat 1:1 personnalisé",
        "Stratégie carrière internationale",
        "Optimisation CV + LinkedIn",
        "Recommandation professionnelle",
        "Accès illimité & mises à jour futures",
      ],
    },
  }

  const plan = plans[selectedPlan]

  return (
    <div
      className="modalOverlay"
      onClick={() => setSelectedPlan(null)}
    >
      <div
        className="modalContent pricingModal scrollableModal"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          className="modalClose"
          onClick={() => setSelectedPlan(null)}
        >
          ✕
        </button>

        <h2>{plan.title}</h2>
        <p className="planDuration">{plan.duration}</p>

        <p className="planDescription">{plan.description}</p>

        <ul className="planDetailsList">
          {plan.features.map((item, i) => (
            <li key={i}>✔ {item}</li>
          ))}
        </ul>

        <button
          className="btnPrimary full"
          onClick={() => {
            setSelectedPlan(null)
            setShowRegister(true)
          }}
        >
          Rejoindre maintenant
        </button>
      </div>
    </div>
  )
}