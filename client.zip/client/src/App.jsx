import { useEffect, useRef, useState } from "react"
import gsap from "gsap"
import { ScrollTrigger } from "gsap/ScrollTrigger"
import "./App.css"
import RegisterModal from "./RegisterModal"
import PricingDetailsModal from "./PricingDetailsModal"
import LoginModal from "./LoginModal";

gsap.registerPlugin(ScrollTrigger)

export default function App() {

  const [selectedPlan, setSelectedPlan] = useState(null)
  const [showRegister, setShowRegister] = useState(false)
  const [showLogin, setShowLogin] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false)
  const [showTop, setShowTop] = useState(false)
  const height = document.documentElement.scrollHeight - window.innerHeight
const progress = height > 0 ? scroll / height : 0

  const heroRef = useRef(null)
  const sectionsRef = useRef([])
  const skillsRef = useRef([])
  const countersRef = useRef([])

  /* ðŸ”¥ NEW REFS FOR CIRCULAR PROGRESS */
  const progressCircleRef = useRef(null)
  const progressTextRef = useRef(null)

  const setSectionRef = (el, i) => sectionsRef.current[i] = el
  const setSkillRef = (el, i) => skillsRef.current[i] = el
  const setCounterRef = (el, i) => countersRef.current[i] = el

  const year = new Date().getFullYear()

  /* ================= DATA ================= */

  const skills = [
    { name: "Big Data & Data Engineering", value: 92 },
    { name: "Artificial Intelligence", value: 88 },
    { name: "Flutter & Dart", value: 90 },
    { name: "Java & Kotlin", value: 83 },
    { name: "Full Stack Web Dev", value: 87 },
    { name: "IoT Systems", value: 80 },
  ]

  const timelineItems = [
    { year: "2025", title: "Big Data Coaching", desc: "Scaling premium training platform." },
    { year: "2022", title: "IoT Systems", desc: "Smart embedded systems." },
    { year: "2021", title: "AI Research", desc: "Architectures & publications." },
    { year: "2012", title: "Web & Mobile Platforms", desc: "Professional deployments." },
    
  ]

  /* ================= SCROLL BUTTON ================= */

  useEffect(() => {

    const handleScroll = () => {

      if (window.scrollY > 450) {
        setShowTop(true)
      } else {
        setShowTop(false)
      }

    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)

  }, [])

  /* ================= LOCK BODY ================= */

useEffect(() => {
  if (showRegister || selectedPlan || showLogin) {
    document.body.style.overflow = "hidden"
  } else {
    document.body.style.overflow = "auto"
  }
}, [showRegister, selectedPlan, showLogin])

  /* ================= GSAP ANIMATIONS ================= */

  useEffect(() => {

    const ctx = gsap.context(() => {

      if (heroRef.current) {
        gsap.from(heroRef.current.children, {
          y: 60,
          opacity: 0,
          duration: 1.2,
          stagger: 0.2,
        })
      }

      sectionsRef.current.forEach((el) => {
        if (!el) return
        gsap.from(el, {
          y: 60,
          opacity: 0,
          duration: 1,
          scrollTrigger: {
            trigger: el,
            start: "top 85%",
          }
        })
      })

      /* Skills animation */
      skillsRef.current.forEach((bar, index) => {
        if (!bar) return
        const value = parseInt(bar.dataset.progress)
        const counter = countersRef.current[index]

        gsap.to(bar, {
          width: value + "%",
          duration: 1.3,
          ease: "power3.out",
          scrollTrigger: {
            trigger: bar,
            start: "top 85%",
          }
        })

        gsap.to(counter, {
          innerText: value,
          duration: 1.3,
          snap: { innerText: 1 },
          scrollTrigger: {
            trigger: bar,
            start: "top 85%",
          },
          onUpdate: function () {
            counter.innerText = Math.ceil(counter.innerText) + "%"
          }
        })
      })

      /* Timeline */
      gsap.from(".tlLine", {
        scaleY: 0,
        transformOrigin: "top",
        duration: 1,
        scrollTrigger: {
          trigger: ".timelineWrap",
          start: "top 85%",
        }
      })

      gsap.from(".tlItem", {
        y: 30,
        opacity: 0,
        stagger: 0.12,
        duration: 0.6,
        scrollTrigger: {
          trigger: ".timelineWrap",
          start: "top 85%",
        }
      })

    })

    ScrollTrigger.refresh()
    return () => ctx.revert()

  }, [])

  /* ================= CIRCULAR SCROLL PROGRESS ================= */

  useEffect(() => {

    const circle = progressCircleRef.current
    const text = progressTextRef.current

    const radius = 45
    const circumference = 2 * Math.PI * radius

    circle.style.strokeDasharray = circumference
    circle.style.strokeDashoffset = circumference

    const updateProgress = () => {

      const scroll = window.scrollY
      const height = document.documentElement.scrollHeight - window.innerHeight
      const progress = scroll / height

      const offset = circumference - progress * circumference

      circle.style.strokeDashoffset = offset
      text.innerText = Math.round(progress * 100) + "%"

    }

    window.addEventListener("scroll", updateProgress)
    return () => window.removeEventListener("scroll", updateProgress)

  }, [])

  return (
    <div className="page">

      {/* ================= NAV ================= */}
  {/* ================= NAV ================= */}
<header className="nav">
  <div className="container navInner">

    <div className="logo">
      <img src="/img/logo.png" alt="Logo" className="logoImg" />
      <div>
        <div className="logoTitle">Big Data Coaching</div>
        <div className="logoSub">Big Data - IA et IoT</div>
      </div>
    </div>

    {/* BURGER MOBILE */}
    <div className="burger" onClick={() => setMenuOpen(!menuOpen)}>
      <span></span>
      <span></span>
      <span></span>
    </div>

    {/* NAV LINKS */}
    <nav className={`navLinks ${menuOpen ? "open" : ""}`}>
      <a href="#coach" onClick={()=>setMenuOpen(false)}>Coach</a>
      <a href="#pricing" onClick={()=>setMenuOpen(false)}>Offres</a>
      <a href="#contact" onClick={()=>setMenuOpen(false)}>Contact</a>

      <button
  className="btnPrimary small"
  onClick={()=> {
    setShowRegister(true)
    setMenuOpen(false)
  }}
>
  S’inscrire
</button>
    </nav>

  </div>
</header>

      {/* ================= HERO ================= */}
      <section className="hero" ref={heroRef}>
        <div className="container">
          <h1>Maitrisez le <span>Big Data</span>, l'IA & l'IoT</h1>
          <p>Formation stratégique, projets réels & mentorat premium.</p>
        </div>
      </section>

      {/* ================= CONTENT (existant inchangÃ©) ================= */}
      {/* Ici ton coach, pricing, contact restent identiques */}
      
      {/* ================= COACH PORTFOLIO ================= */}
      <section id="coach" className="section dark" ref={(el)=>setSectionRef(el,0)}>
        <div className="container coachPortfolioPremium">

          <div className="coachHeader">
            <img src="/img/georges.jpeg" className="coachImgCircle" />
            <h2>Dr MALOANI SAIDI Georges</h2>
            <h4>Big Data Architect | AI Researcher | IoT Specialist</h4>
            <p className="coachTagline">
              PhD Candidate - AI - IoT & Big Data
            </p>
          </div>

          <div className="portfolioSection">
            <h3> Niveau d'Expertise</h3>

            {skills.map((skill, i) => (
              <div className="skillItem" key={skill.name}>
                <div className="skillHeader">
                  <span>{skill.name}</span>
                  <span ref={(el)=>setCounterRef(el,i)} className="skillCounter">0%</span>
                </div>
                <div className="skillBar">
                  <div
                    ref={(el)=>setSkillRef(el,i)}
                    data-progress={skill.value}
                    className="skillProgress"
                  />
                </div>
              </div>
            ))}
          </div>

          <div className="portfolioSection">
            <h3> Parcours</h3>
            <div className="timelineWrap">
              <div className="tlLine"></div>
              <div className="tlItems">
                {timelineItems.map(item => (
                  <div className="tlItem" key={item.year}>
                    <div className="tlDot"></div>
                    <div className="tlCard">
                      <div className="tlTop">
                        <span className="tlYear">{item.year}</span>
                        <span className="tlTitle">{item.title}</span>
                      </div>
                      <p className="tlDesc">{item.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

        </div>
      </section>

      {/* ================= PRICING ================= */}
      <section id="pricing" className="section" ref={(el)=>setSectionRef(el,1)}>
        <div className="container">
          <h2>Nos Offres Premium</h2>

          <div className="grid">

            <div className="pricingCard">
              <h3>Starter à  99$</h3>
              <p>Idéal pour débuter en Big Data.</p>
              <button onClick={() => setSelectedPlan("starter")} className="btnOutline full">
                Voir les détails
              </button>
            </div>

            <div className="pricingCard featured">
              <h3>Pro à 249$</h3>
              <p>Programme complet Data Engineer.</p>
              <button onClick={() => setSelectedPlan("pro")} className="btnOutline full">
                Voir les détails
              </button>
            </div>

            <div className="pricingCard">
              <h3>Elite à 599$</h3>
              <p>Mentorat personnalisé & IA avancée.</p>
              <button onClick={() => setSelectedPlan("elite")} className="btnOutline full">
                Voir les détails
              </button>
            </div>

          </div>
        </div>
      </section>

      {/* ================= CONTACT ================= */}
      <section id="contact" className="section dark" ref={(el)=>setSectionRef(el,2)}>
        <div className="container contactPro">
          <h2>Contact</h2>

          <div className="contactCards">
            <div className="contactCard">
              <h4>Email</h4>
              <a href="mailto:georgesmaloanis@gmail.com">
                georgesmaloanis@gmail.com
              </a>
            </div>

            <div className="contactCard">
              <h4>WhatsApp</h4>
              <a href="https://wa.me/243826704930" target="_blank" rel="noopener noreferrer">
                +243 826 704 930
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* ================= FOOTER ================= */}
      <footer className="footer">
        © {year} Big Data Coaching - MS Solutions Lab
      </footer>

      {/* ================= SCROLL TOP BUTTON ================= */}
      {showTop && (
        <button
          className="scrollTop"
          onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
        >
          â†‘
        </button>
      )}

      {/* ================= CIRCULAR PROGRESS ================= */}
      <div
        className="circularProgress"
        onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
      >
        <svg width="110" height="110">
          <circle
            cx="55"
            cy="55"
            r="45"
            stroke="rgba(255,255,255,0.1)"
            strokeWidth="6"
            fill="none"
          />
          <circle
            ref={progressCircleRef}
            cx="55"
            cy="55"
            r="45"
            stroke="url(#gradient)"
            strokeWidth="6"
            fill="none"
            strokeLinecap="round"
            transform="rotate(-90 55 55)"
          />
          <defs>
            <linearGradient id="gradient">
              <stop offset="0%" stopColor="#00c6ff"/>
              <stop offset="100%" stopColor="#ff9800"/>
            </linearGradient>
          </defs>
        </svg>

        <div ref={progressTextRef} className="progressText">0%</div>
      </div>

      {/* ================= MODALS ================= */}
     {showRegister && (
      <RegisterModal
        showRegister={showRegister}
        setShowRegister={setShowRegister}
        setShowLogin={setShowLogin}   // 🔥 AJOUT
      />
    )}
    {showLogin && (
  <LoginModal
    showLogin={showLogin}
    setShowLogin={setShowLogin}
    setShowRegister={setShowRegister}
  />
)}

      <PricingDetailsModal
        selectedPlan={selectedPlan}
        setSelectedPlan={setSelectedPlan}
        setShowRegister={setShowRegister}
      />

    </div>
  )
}