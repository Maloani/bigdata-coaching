import { useEffect, useMemo, useState } from "react";
import PhoneInput, { isValidPhoneNumber } from "react-phone-number-input";
import "react-phone-number-input/style.css";

export default function RegisterModal({ showRegister, setShowRegister, setShowLogin }) {

  const [form, setForm] = useState({
    fullName: "",
    email: "",
    phone: "",
    password: "",
    acceptTerms: false,
  });

  const [country, setCountry] = useState("UG");
  const [otpSent, setOtpSent] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  /* =========================
     DETECTION AUTOMATIQUE PAYS
  ========================= */
  useEffect(() => {
    async function detectCountry() {
      try {
        const res = await fetch("https://ipapi.co/json/");
        const data = await res.json();
        if (data?.country) {
          setCountry(data.country);
        }
      } catch (err) {
        console.log("IP detection failed");
      }
    }
    detectCountry();
  }, []);

  /* =========================
     PASSWORD CHECKS
  ========================= */
  const passwordChecks = {
    length: form.password.length >= 8,
    upper: /[A-Z]/.test(form.password),
    lower: /[a-z]/.test(form.password),
    number: /[0-9]/.test(form.password),
    special: /[^A-Za-z0-9]/.test(form.password),
  };

  const passwordScore = Object.values(passwordChecks).filter(Boolean).length;

  const passwordStrength =
    passwordScore <= 2 ? "Faible" :
    passwordScore === 3 ? "Moyen" :
    passwordScore === 4 ? "Bon" :
    "Très fort";

  /* =========================
     VALIDATIONS
  ========================= */
  const errors = useMemo(() => {
    const e = {};

    if (!form.fullName) e.fullName = "Nom requis";
    if (!form.email.includes("@")) e.email = "Email invalide";
    if (!form.phone || !isValidPhoneNumber(form.phone))
      e.phone = "Numéro invalide";

    if (passwordScore < 3)
      e.password = "Mot de passe trop faible";

    if (!form.acceptTerms)
      e.acceptTerms = "Vous devez accepter les conditions";

    return e;
  }, [form, passwordScore]);

  const isValid = Object.keys(errors).length === 0;

  const setField = (name, value) =>
    setForm((p) => ({ ...p, [name]: value }));

  const sendOTP = async () => {
    if (!form.phone) return;
    setOtpSent(true);
    alert("OTP envoyé au numéro : " + form.phone);
  };

  if (!showRegister) return null;

  return (
    <div className="modalOverlay" onClick={() => setShowRegister(false)}>
      <div className="modalContent scrollableModal" onClick={(e) => e.stopPropagation()}>
        <button className="modalClose" onClick={() => setShowRegister(false)}>✕</button>

        <h2>Créer un compte</h2>

        <form className="registerForm">

          {/* NOM */}
          <input
            placeholder="Nom complet"
            value={form.fullName}
            onChange={(e) => setField("fullName", e.target.value)}
          />
          {errors.fullName && <small className="err">{errors.fullName}</small>}

          {/* EMAIL */}
          <input
            type="email"
            placeholder="Email professionnel"
            value={form.email}
            onChange={(e) => setField("email", e.target.value)}
          />
          {errors.email && <small className="err">{errors.email}</small>}

          {/* TELEPHONE */}
          <div className="phoneWrapper">
            <PhoneInput
              international
              defaultCountry={country}
              value={form.phone}
              onChange={(value) => setField("phone", value)}
            />
          </div>
          {errors.phone && <small className="err">{errors.phone}</small>}

          {form.phone && (
            <div className="phonePreview">
              Numéro formaté : <strong>{form.phone}</strong>
            </div>
          )}

          {form.phone && !otpSent && (
            <button type="button" className="btnOutline full" onClick={sendOTP}>
              Vérifier par SMS (OTP)
            </button>
          )}

          {/* PASSWORD */}
          <div className="passwordWrapper">
            <input
              type={showPassword ? "text" : "password"}
              placeholder="Mot de passe"
              value={form.password}
              onChange={(e) => setField("password", e.target.value)}
            />
            <span
              className="eyeIcon"
              onClick={() => setShowPassword(!showPassword)}
            >
              {showPassword ? "🙈" : "👁"}
            </span>
          </div>

          {/* PASSWORD CONDITIONS */}
          <div className="passwordConditions">
            <p className={passwordChecks.length ? "validCond" : ""}>✔ 8 caractères minimum</p>
            <p className={passwordChecks.upper ? "validCond" : ""}>✔ Une majuscule</p>
            <p className={passwordChecks.lower ? "validCond" : ""}>✔ Une minuscule</p>
            <p className={passwordChecks.number ? "validCond" : ""}>✔ Un chiffre</p>
            <p className={passwordChecks.special ? "validCond" : ""}>✔ Un symbole</p>
          </div>

          <div className="strengthBar">
            <div
              className="strengthFill"
              style={{ width: `${(passwordScore / 5) * 100}%` }}
            ></div>
          </div>
          <div className="strengthLabel">{passwordStrength}</div>

          {errors.password && <small className="err">{errors.password}</small>}

          {/* CONDITIONS */}
          <label className="terms">
            <input
              type="checkbox"
              checked={form.acceptTerms}
              onChange={(e) => setField("acceptTerms", e.target.checked)}
            />
            <span>
              J’accepte les Conditions d’utilisation et la Politique de confidentialité.
            </span>
          </label>
          {errors.acceptTerms && <small className="err">{errors.acceptTerms}</small>}

          <button className="btnPrimary full" disabled={!isValid}>
            Créer mon compte
          </button>

          <p className="loginLink">
            Vous avez déjà un compte ?{" "}
            <span onClick={() => { setShowRegister(false); setShowLogin(true); }}>
              Connectez-vous
            </span>
          </p>

        </form>
      </div>
    </div>
  );
}