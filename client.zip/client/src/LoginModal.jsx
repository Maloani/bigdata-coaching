import { useEffect, useRef, useState } from "react";
import gsap from "gsap";

export default function LoginModal({
  showLogin,
  setShowLogin,
  setShowRegister
}) {

  const modalRef = useRef(null);
  const circleRef = useRef(null);
  const barRef = useRef(null);
  const counterRef = useRef(null);

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [useOTP, setUseOTP] = useState(false);
  const [otpSent, setOtpSent] = useState(false);
  const [otp, setOtp] = useState("");

  const [timer, setTimer] = useState(0);
  const [attempts, setAttempts] = useState(0);

  const MAX_ATTEMPTS = 3;
  const RADIUS = 30;
  const CIRCUMFERENCE = 2 * Math.PI * RADIUS;

  /* ================= MODAL ANIMATION ================= */
  useEffect(() => {
    if (showLogin && modalRef.current) {
      gsap.fromTo(
        modalRef.current,
        { opacity: 0, y: 50, scale: 0.95 },
        { opacity: 1, y: 0, scale: 1, duration: 0.4 }
      );
    }
  }, [showLogin]);

  /* ================= TIMER ================= */
  useEffect(() => {
    if (timer <= 0) return;

    const interval = setInterval(() => {
      setTimer((prev) => prev - 1);
    }, 1000);

    return () => clearInterval(interval);
  }, [timer]);

  /* ================= PROGRESS ANIMATION ================= */
  useEffect(() => {
    if (!circleRef.current || timer <= 0) return;

    const progress = timer / 60;
    const offset = CIRCUMFERENCE - progress * CIRCUMFERENCE;

    gsap.to(circleRef.current, {
      strokeDashoffset: offset,
      duration: 0.5
    });

    gsap.to(barRef.current, {
      width: `${progress * 100}%`,
      duration: 0.5
    });

    if (counterRef.current) {
      counterRef.current.innerText = timer + "s";
    }

  }, [timer]);

  if (!showLogin) return null;

  const sendOTP = () => {
    if (!email) return alert("Entrez votre email");

    if (attempts >= MAX_ATTEMPTS) {
      return alert("Limite de tentatives atteinte.");
    }

    setOtpSent(true);
    setTimer(60);
    setAttempts((prev) => prev + 1);
  };

  return (
    <div className="modalOverlay" onClick={() => setShowLogin(false)}>
      <div
        ref={modalRef}
        className="modalContent"
        onClick={(e) => e.stopPropagation()}
      >
        <button className="modalClose" onClick={() => setShowLogin(false)}>
          ✕
        </button>

        <h2>Connexion</h2>

        <form className="registerForm">

          <input
            type="email"
            placeholder="Email professionnel"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />

          {!useOTP && (
            <div className="passwordWrapper">
              <input
                type={showPassword ? "text" : "password"}
                placeholder="Mot de passe"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
              <span
                className="eyeIcon"
                onClick={() => setShowPassword(!showPassword)}
              >
                {showPassword ? "🙈" : "👁"}
              </span>
            </div>
          )}

          {/* OTP MODE */}
          {useOTP && (
            <>
              {!otpSent && (
                <button
                  type="button"
                  className="btnOutline full"
                  onClick={sendOTP}
                  disabled={attempts >= MAX_ATTEMPTS}
                >
                  Envoyer OTP
                </button>
              )}

              {otpSent && (
                <>
                  <div className="otpProgressWrapper">

                    {/* CIRCLE */}
                    <svg width="80" height="80">
                      <circle
                        cx="40"
                        cy="40"
                        r={RADIUS}
                        stroke="rgba(255,255,255,0.1)"
                        strokeWidth="5"
                        fill="none"
                      />
                      <circle
                        ref={circleRef}
                        cx="40"
                        cy="40"
                        r={RADIUS}
                        stroke="#00c6ff"
                        strokeWidth="5"
                        fill="none"
                        strokeDasharray={CIRCUMFERENCE}
                        strokeDashoffset={0}
                        strokeLinecap="round"
                        transform="rotate(-90 40 40)"
                      />
                    </svg>

                    <div className="otpCounter" ref={counterRef}>
                      {timer}s
                    </div>

                  </div>

                  {/* BAR */}
                  <div className="timerBarContainer">
                    <div className="timerBar" ref={barRef}></div>
                  </div>

                  <input
                    type="text"
                    placeholder="Entrer le code OTP"
                    value={otp}
                    onChange={(e) => setOtp(e.target.value)}
                  />

                  <button
                    type="button"
                    className="btnOutline full"
                    disabled={timer > 0 || attempts >= MAX_ATTEMPTS}
                    onClick={sendOTP}
                  >
                    {attempts >= MAX_ATTEMPTS
                      ? "Limite atteinte"
                      : timer > 0
                      ? `Renvoyer dans ${timer}s`
                      : "Renvoyer le code"}
                  </button>

                  <small>
                    Tentatives : {attempts} / {MAX_ATTEMPTS}
                  </small>
                </>
              )}
            </>
          )}

          <button className="btnPrimary full">
            Se connecter
          </button>

          <div className="divider"><span>OU</span></div>

          <button
            type="button"
            className="btnOutline full"
            onClick={() => {
              setUseOTP(!useOTP);
              setOtpSent(false);
              setTimer(0);
              setAttempts(0);
            }}
          >
            {useOTP ? "Connexion classique" : "Connexion avec OTP"}
          </button>

          <p className="loginLink">
            Pas encore de compte ?{" "}
            <span
              onClick={() => {
                setShowLogin(false);
                setShowRegister(true);
              }}
            >
              Créer un compte
            </span>
          </p>

        </form>
      </div>
    </div>
  );
}