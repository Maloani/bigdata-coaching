require("dotenv").config();
const express = require("express");
const cors = require("cors");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const Stripe = require("stripe");
const db = require("./db");
const auth = require("./middleware/auth");

const app = express();
const stripe = Stripe(process.env.STRIPE_SECRET_KEY);

app.use(cors({ origin: process.env.CLIENT_URL }));
app.use(express.json());

// Health
app.get("/", (_, res) => res.send("Big Data Coaching API OK"));

// AUTH: Register
app.post("/auth/register", async (req, res) => {
  const { fullname, email, password } = req.body || {};
  if (!fullname || !email || !password) return res.status(400).json({ message: "Champs manquants" });

  const hash = await bcrypt.hash(password, 10);

  try {
    const result = await db.query(
      "INSERT INTO users(fullname,email,password_hash) VALUES($1,$2,$3) RETURNING id,fullname,email,role",
      [fullname, email.toLowerCase(), hash]
    );

    const user = result.rows[0];
    const token = jwt.sign({ id: user.id, email: user.email, role: user.role }, process.env.JWT_SECRET, { expiresIn: "7d" });

    res.json({ token, user });
  } catch (e) {
    if (String(e).includes("duplicate")) return res.status(409).json({ message: "Email déjà utilisé" });
    return res.status(500).json({ message: "Erreur serveur" });
  }
});

// AUTH: Login
app.post("/auth/login", async (req, res) => {
  const { email, password } = req.body || {};
  if (!email || !password) return res.status(400).json({ message: "Champs manquants" });

  const result = await db.query("SELECT * FROM users WHERE email=$1", [email.toLowerCase()]);
  const user = result.rows[0];
  if (!user) return res.status(401).json({ message: "Email ou mot de passe incorrect" });

  const ok = await bcrypt.compare(password, user.password_hash);
  if (!ok) return res.status(401).json({ message: "Email ou mot de passe incorrect" });

  const safeUser = { id: user.id, fullname: user.fullname, email: user.email, role: user.role };
  const token = jwt.sign({ id: user.id, email: user.email, role: user.role }, process.env.JWT_SECRET, { expiresIn: "7d" });

  res.json({ token, user: safeUser });
});

// STRIPE: create checkout session (direct)
const PRICES = {
  basic: { name: "Big Data Coaching - Basic", amount_cents: 9900 },
  pro:   { name: "Big Data Coaching - Pro",   amount_cents: 24900 },
  elite: { name: "Big Data Coaching - Elite", amount_cents: 59900 },
};

app.post("/payments/stripe/create-checkout-session", auth, async (req, res) => {
  const plan = (req.body?.plan || "").toLowerCase();
  const item = PRICES[plan];
  if (!item) return res.status(400).json({ message: "Plan invalide" });

  // Create Stripe session
  const session = await stripe.checkout.sessions.create({
    mode: "payment",
    payment_method_types: ["card"],
    customer_email: req.user.email,
    line_items: [{
      price_data: {
        currency: "usd",
        product_data: { name: item.name },
        unit_amount: item.amount_cents,
      },
      quantity: 1,
    }],
    metadata: { user_id: String(req.user.id), plan },
    success_url: `${process.env.CLIENT_URL}/success`,
    cancel_url: `${process.env.CLIENT_URL}/cancel`,
  });

  // Save pending purchase
  await db.query(
    "INSERT INTO purchases(user_id, plan, amount_cents, currency, status, stripe_session_id) VALUES($1,$2,$3,$4,$5,$6)",
    [req.user.id, plan, item.amount_cents, "usd", "pending", session.id]
  );

  res.json({ url: session.url });
});

// STRIPE webhook needs raw body -> separate middleware
app.post("/webhooks/stripe", express.raw({ type: "application/json" }), async (req, res) => {
  let event;
  try {
    event = stripe.webhooks.constructEvent(req.body, req.headers["stripe-signature"], process.env.STRIPE_WEBHOOK_SECRET);
  } catch (err) {
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }

  // Payment success
  if (event.type === "checkout.session.completed") {
    const session = event.data.object;
    const sessionId = session.id;

    // Mark purchase paid
    await db.query("UPDATE purchases SET status='paid' WHERE stripe_session_id=$1", [sessionId]);

    // TODO: here you can also grant access to courses, set role, etc.
  }

  res.json({ received: true });
});

// Start
app.listen(process.env.PORT || 5000, () => {
  console.log(`API running on :${process.env.PORT || 5000}`);
});